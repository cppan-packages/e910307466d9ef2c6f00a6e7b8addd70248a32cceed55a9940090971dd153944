

#ifndef __ETL_PLATFORM_ARDUINO__

#define COMPILER_GCC
#define PLATFORM_ARM

#endif
